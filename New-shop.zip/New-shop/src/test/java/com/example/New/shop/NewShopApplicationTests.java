package com.example.New.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
