package com.example.New.shop.entities.enums;

public enum OrderStatus {
    NEW, APPROVED, CANCELED, PAID, CLOSED
}
