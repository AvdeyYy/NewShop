package com.example.New.shop.service;
import com.example.New.shop.entities.Bucket;
import com.example.New.shop.entities.Product;
import com.example.New.shop.entities.User;
import com.example.New.shop.repo.BucketRepository;
import com.example.New.shop.repo.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor
public class BucketServiceImpl implements BucketService {
    @Autowired
    private final BucketRepository bucketRepository;
    @Autowired
    private final ProductRepository productRepository;

    @Override
    public Bucket createBucket(User user, List<Long> productsId) {
        Bucket bucket = new Bucket();
        bucket.setUser(user);
        List<Product> productList = getProductsById(productsId);
        bucket.setProducts(productList);
        return bucketRepository.save(bucket);
    }
    @Override
    public List<Product> getProductsById(List<Long> productsId) {
        return productsId.stream()
                .map(productRepository::getOne)
                .collect(Collectors.toList());
        }
    @Override
    public void addProduct(Bucket bucket, List<Long> productId) {
        List<Product> productList = bucket.getProducts();
        List<Product> products = productList == null ? new ArrayList<>() : new ArrayList<>(productList);
    }
}
