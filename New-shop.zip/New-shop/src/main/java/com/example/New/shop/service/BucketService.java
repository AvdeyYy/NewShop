package com.example.New.shop.service;

import com.example.New.shop.entities.Bucket;
import com.example.New.shop.entities.Product;
import com.example.New.shop.entities.User;
import java.util.List;


public interface BucketService {
    Bucket createBucket(User user, List<Long> productsId);

    List<Product> getProductsById(List<Long> productsId);

    void addProduct(Bucket bucket, List<Long> productId);
}