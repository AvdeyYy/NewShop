package com.example.New.shop.entities.enums;

import org.springframework.security.core.GrantedAuthority;

public enum Roles {
    ADMIN, CLIENT;
}
