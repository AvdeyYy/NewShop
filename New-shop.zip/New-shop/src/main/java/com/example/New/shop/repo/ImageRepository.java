package com.example.New.shop.repo;

import com.example.New.shop.entities.Image;
import org.springframework.data.repository.CrudRepository;

public interface ImageRepository extends CrudRepository<Image, Long> {
}
